const imgStore = [
	'https://images.unsplash.com/photo-1464688768931-1c8024786293?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=750&q=80',
	'https://images.unsplash.com/photo-1516651986872-1af15f3b7e4d?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=667&q=80',
	'https://images.unsplash.com/photo-1461638273344-c45a4eab94e1?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=750&q=80',
	'https://images.unsplash.com/photo-1472715457064-704ad183d82d?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjE3MzYxfQ&auto=format&fit=crop&w=750&q=80',
	'https://images.unsplash.com/photo-1529239672822-1c8572f76b41?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60'
];

const img = document.querySelector('.img');
const position = img.getAttribute('data-position');
img.setAttribute('src', imgStore[position]);

const next = document.querySelector('.next');
const prev = document.querySelector('.prev');

next.addEventListener('click', function() {
	let position = img.getAttribute('data-position');
	
	if (position == imgStore.length-1) {
		position = -1;
	}

	img.setAttribute('src', imgStore[++position]);
	img.setAttribute('data-position', position);
})

prev.addEventListener('click', function() {
	let position = img.getAttribute('data-position');

	if (position == 0) {
		position = imgStore.length;
	}

	img.setAttribute('src', imgStore[--position]);
	img.setAttribute('data-position', position);
})